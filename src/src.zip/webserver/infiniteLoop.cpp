#include <iostream>
int main()
{
	while(true){}
	std::cout << "here";
}